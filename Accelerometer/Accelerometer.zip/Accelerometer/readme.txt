This project display
Azimuth, Pitch and Roll values according to the movement of the device